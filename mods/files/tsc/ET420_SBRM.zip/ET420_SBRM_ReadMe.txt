Rekrut Kurbel's ET420 S-Bahn Rhein-Main Repaint
---
Hier mein S-Bahn Rhein-Main Repaint für den 420er von Influenzo. Entstand vor zwei Jahren, weil ich mit den anderen vorhandenen Repaints von der Qualität her nicht wirklich überzeugt war.
---
Installation:
	Den Assets-Ordner ins Railworks-Hauptverzeichnis entpacken, danach im Assets-Ordner die "RK_Install_ET420_SBRM.bat" ausführen.