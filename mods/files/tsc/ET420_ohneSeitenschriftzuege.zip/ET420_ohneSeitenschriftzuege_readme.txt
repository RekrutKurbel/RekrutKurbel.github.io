ET420 verkehrsrot ohne seitliche Schriftzüge
---

Dieses kleine Texturrepaint entfernt am verkehrsroten 420er den "S-Bahn München"-Schriftzug und die "DB Bahn"-Logos an den Türen, da die wenigen verkehrsroten Münchener 420er der ersten Bauserie in dessen letzten Betriebsjahren diese nie trugen. (Jedenfalls hab ich keine Bilder davon gesehen)

---

Installation:

Den enthaltenen Assets-Ordner ins Railworks-Hauptverzeichnis entpacken und überschreiben lassen.