DE:
Baureihe 234 PZB-Skriptmodifikation
-----
Für die Baureihe 232 von virtualRailroads gibt es von Amisia ein hervorragendes Repaint-Pack, welches unter anderem auch 234er ins Spiel bringt, die auch 140 km/h erreichen können. Das Problem ist allerdings, dass die PZB weiterhin für die BR232 ausgelegt ist und ab 125 km/h die Lok automatisch herunterbremst. 
Diese Skriptmodifikation hebt die PZB-Höchstgeschwindigkeit auf 145 km/h an und wendet sie an den 234ern des Packs an. Das Originalskript wird hiervon nicht überschrieben, das heißt, die PZB der 232er wird weiterhin so funktionieren, wie sie soll.
-----
VORAUSSETZUNGEN:
	- vR DB BR232
		- https://virtual-railroads.de/de/diesellokomotiven/191-db-br232-.html
	- Ludmilla Repaint Packs 1, 2 und 3
		- https://rail-sim.de/forum/filebase/entry/6984-rdaf-ludmilla-repaint-pack/
		- https://rail-sim.de/forum/filebase/entry/7064-rdaf-ludmilla-repaint-pack-02/
		- https://rail-sim.de/forum/filebase/entry/7264-rdaf-ludmilla-repaint-pack-03/
-----
INSTALLATION:
	- Den Assets-Ordner ins Railworks-Verzeichnis entpacken. Die 4 BIN-Dateien überschreiben lassen, sonst steuern sie das neue Skript nicht an!

--------------------

EN:
Baureihe 234 PZB script modification
-----
For the Baureihe 232 from virtualRailroads, there is an extraordinary repaint pack made by Amisia which will also add 234s into the game, that can reach 140 km/h. The problem is that the PZB is still interpreted for the BR232 and will automatically brake the loco above 125 km/h.
This script modification raises the PZB top speed to 145 km/h and applies it to the 234s of that pack. The original script will not be overwritten by this, making the PZB of the 232s still work as they should.
-----
DEPENDENCIES:
	- vR DB BR232
		- https://virtual-railroads.de/de/diesellokomotiven/191-db-br232-.html
	- Ludmilla Repaint Packs 1, 2 und 3
		- https://rail-sim.de/forum/filebase/entry/6984-rdaf-ludmilla-repaint-pack/
		- https://rail-sim.de/forum/filebase/entry/7064-rdaf-ludmilla-repaint-pack-02/
		- https://rail-sim.de/forum/filebase/entry/7264-rdaf-ludmilla-repaint-pack-03/
-----
INSTALLATION:
	- Unpack the Assets folder into the RailWorks directory. Overwrite the 4 BIN files, otherwise they won't call the new script!